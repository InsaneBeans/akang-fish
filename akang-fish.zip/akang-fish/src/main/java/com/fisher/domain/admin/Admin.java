package com.fisher.domain.admin;


public class Admin {

}
